document.querySelectorAll("input[value=\"3\"]").forEach(el => {
    el.click();
});

document.querySelectorAll("input[name=\"ans[y6]\"]")[0].click();
document.querySelectorAll("button[type=\"submit\"]")[0].click();